//
//  ViewController.swift
//  RBTest
//
//  Created by APPLE on 09/04/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit
import SDWebImage

class HomeViewController: UIViewController {

    @IBOutlet weak var inputTxtField: UITextField!
    @IBOutlet weak var cvContainer: UIView!
    
    var hideCVContainer : Bool!

    var theProductStruct = ProductStruct()
//    var theProductDataArr = [ProductDataStruct]()
//    var theProductBrandArr = [ProductBrandStruct]()
    
    @IBOutlet weak var cartCollectionView: UICollectionView!
    
    var addToCartBtnIndexPath : IndexPath! = nil
    var incrementIndexPath : IndexPath! = nil
    var decrementIndexPath : IndexPath! = nil
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        inputTxtField.delegate = self
        if hideCVContainer {
            cvContainer.isHidden = true
        }else{
            cvContainer.isHidden = false
        }
        
        cartCollectionView.delegate = self
        cartCollectionView.dataSource = self
    }
    
    @IBAction func hitBtnTapped(_ sender: UIButton) {
        
        guard let searchKey = inputTxtField.text, !searchKey.isEmpty else {
            print("No name to submit")
            return
        }
        
        callService(key: searchKey)

    }
    func callService(key : String) {
        let RequestDict : [String : Any] = ["search_key":key,"limit required":10]
        print("REquest Dict = ",RequestDict)
        
        WebServiceClass().jsonInputWebServiceMethod(parameterDict: RequestDict) { (FullResponse, ResponseStatus) in
            
            
            if ResponseStatus {
                let fullResponseDict = FullResponse as! [String:AnyObject]
                //                print("fullResponse =",fullResponseDict)
                
                let ResponseDict = fullResponseDict ["Status_Response"] as! [String:AnyObject]
                print("ResponseDict =",ResponseDict)
                saveProductResponce(ProductResponce: ResponseDict)
                print("SAved Successssssfully")
                if self.inputTxtField.isFirstResponder {
                    self.inputTxtField.resignFirstResponder()
                }
                self.cvContainer.isHidden = false

                self.theProductStruct.Message = "\(ResponseDict["Message"]!)"
                self.theProductStruct.totalProducts = "\(ResponseDict["totalProducts"]!)"
                self.theProductStruct.Currency = "\(ResponseDict["Currency"]!)"
                
                var dataArr = [ProductDataStruct]()
                for aDict in ResponseDict["Data"] as! [[String:AnyObject]] {
                    var structObj = ProductDataStruct()
                    structObj.product_id = "\(aDict["product_id"]!)"
                    structObj.product_title = "\(aDict["product_title"]!)"
                    structObj.image_url = "\(aDict["image_url"]!)"
                    structObj.category_id = "\(aDict["category_id"]!)"
                    structObj.proRating = "\(aDict["proRating"]!)"
                    structObj.totRating = "\(aDict["totRating"]!)"
                    structObj.orgPrice = "\(aDict["orgPrice"]!)"
                    structObj.sellPrice = "\(aDict["sellPrice"]!)"
                    structObj.proPercentage = "\(aDict["proPercentage"]!)"
                    dataArr.append(structObj)
                }
                self.theProductStruct.DataArray = dataArr
                
                var brandArr = [ProductBrandStruct]()
                for aDict in ResponseDict["Brands"] as! [[String:AnyObject]]{
                    var structObj = ProductBrandStruct()
                    structObj.brand_id = "\(aDict["brand_id"]!)"
                    structObj.name = "\(aDict["name"]!)"
                    brandArr.append(structObj)
                }
                self.theProductStruct.BrandsArray = brandArr
                self.cartCollectionView.reloadData()
                
            }
            else {
                print("ResponseStatus is false")
            }
        }
    }
    
}
extension HomeViewController : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
}
extension HomeViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.theProductStruct.DataArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cartCellID", for: indexPath) as! CartCollectionViewCellClass

        if self.theProductStruct.DataArray[indexPath.row].productImgData != nil {
          
            cell.productImgView.image = UIImage(data:self.theProductStruct.DataArray[indexPath.row].productImgData!)
        }else{
            cell.productImgView.sd_setShowActivityIndicatorView(true)
            cell.productImgView.sd_setIndicatorStyle(.white)
            

                cell.productImgView.sd_setImage(with: URL(string: self.theProductStruct.DataArray[indexPath.row].image_url!), placeholderImage: UIImage(named: "starFilledBlue"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImg, error, cacheType, imageURL in
                    if error == nil{
                        self.theProductStruct.DataArray[indexPath.row].productImgData = downloadedImg!.pngData()
                        
                    }else{
                        print("Error from SBWebImage Block to load hotel Image = ",error!)
                    }
                    
                })
        }
        
        cell.productImgView.contentMode = .scaleAspectFit
        cell.productImgView.clipsToBounds = true
        
        
        
        cell.orgPriceLbl.text = self.theProductStruct.Currency + " " + self.theProductStruct.DataArray[indexPath.row].orgPrice
        cell.sellingPriceLbl.text = self.theProductStruct.Currency + " " + self.theProductStruct.DataArray[indexPath.row].sellPrice
        cell.productTitleLbl.text = self.theProductStruct.DataArray[indexPath.row].product_title
        
        cell.addToCartBtn.addTarget(self, action: #selector(self.addToCartBtnTapped), for: .touchUpInside)
        cell.addToCartBtn.tag = indexPath.row
        self.addToCartBtnIndexPath = indexPath
        
//        if cell.addToCartBtnViewFlag {
//            cell.addToCartBtnView.isHidden = true
//        }else{
//            cell.addToCartBtnView.isHidden = false
//        }
        if self.theProductStruct.DataArray[indexPath.row].addToCartBtnViewFlag {
            cell.addToCartBtnView.isHidden = true
        }else{
            cell.addToCartBtnView.isHidden = false
        }
        
        cell.totalLbl.text = "\(self.theProductStruct.DataArray[indexPath.row].noOfItem)"
            
        cell.incrementBtn.addTarget(self, action: #selector(self.incrementBtnTapped), for: .touchUpInside)
        self.incrementIndexPath = indexPath
        cell.incrementBtn.tag = indexPath.row
        
        cell.decrementBtn.addTarget(self, action: #selector(self.decrementBtnTapped), for: .touchUpInside)
        self.decrementIndexPath = indexPath
        cell.decrementBtn.tag = indexPath.row
        
       
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (self.cartCollectionView.frame.width/2)-5, height: (self.cartCollectionView.frame.height/2)-5)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    @objc func addToCartBtnTapped (_sender : UIButton ){

        
        print("addToCart btn tapped")
//        let cell = self.cartCollectionView.cellForItem(at: self.addToCartBtnIndexPath) as! CartCollectionViewCellClass
        self.theProductStruct.DataArray[_sender.tag].addToCartBtnViewFlag = true
//        cell.addToCartBtnView.isHidden = true
//        cell.addToCartBtnViewFlag = true
        
        self.cartCollectionView.reloadData()
        
    }
    @objc func incrementBtnTapped(_sender : UIButton){
        self.theProductStruct.DataArray[_sender.tag].noOfItem += 1
        self.cartCollectionView.reloadData()
    }
    
    @objc func decrementBtnTapped(_ sender: UIButton) {

        if self.theProductStruct.DataArray[sender.tag].noOfItem > 0{
            self.theProductStruct.DataArray[sender.tag].noOfItem -= 1
            if self.theProductStruct.DataArray[sender.tag].noOfItem == 0{
                self.theProductStruct.DataArray[sender.tag].addToCartBtnViewFlag = false
            }
        }else{
            self.theProductStruct.DataArray[sender.tag].addToCartBtnViewFlag = false
        }
         self.cartCollectionView.reloadData()
    }
}

class CartCollectionViewCellClass : UICollectionViewCell {
    
    @IBOutlet weak var productImgView: UIImageView!
    @IBOutlet weak var productTitleLbl: UILabel!
    @IBOutlet weak var orgPriceLbl: UILabel!
    @IBOutlet weak var sellingPriceLbl: UILabel!
    
    @IBOutlet weak var incrementOrDecrementView: UIView!
    @IBOutlet weak var incrementBtn: UIButton!
    @IBOutlet weak var totalLbl: UILabel!
    @IBOutlet weak var decrementBtn: UIButton!
    
    @IBOutlet weak var addToCartBtnView: UIView!
    @IBOutlet weak var addToCartBtn: UIButton!
    
//    var noOfItem : Int = 1
//    var addToCartBtnViewFlag : Bool = false
}
