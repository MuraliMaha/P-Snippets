//
//  WebService.swift
//  WebServiceHandler1
//
//  Created by SunTelematics on 28/06/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit


class WebServiceClass {

    func jsonInputWebServiceMethod(parameterDict : [String:Any],completion:@escaping (_ Data:Any,_ IsSuccess:Bool) -> ())
    {
        
        //Part 1
        let theUrlString = "http://www.beee2c.com/api/product-list"
        let theURL = URL(string: theUrlString)
        
        //Part 2
        var mutableR = URLRequest.init(url: theURL!)
        mutableR.httpMethod = "POST"
        mutableR.allHTTPHeaderFields = ["Content-Type":"application/json"]
        
        mutableR.timeoutInterval = 35
        mutableR.allowsCellularAccess = true
        
        //Part 3
        let ParamsData = try? JSONSerialization.data(withJSONObject: parameterDict, options: .prettyPrinted)
        
        if (ParamsData != nil) {
            mutableR.httpBody = ParamsData!
        }
        else {
            completion([:],false)
            return
        }
        
        
        //Part 4
        let manager = AFHTTPRequestOperation(request: mutableR as URLRequest)
        
        manager.setCompletionBlockWithSuccess({ (operation : AFHTTPRequestOperation, responseObject : Any) -> Void in
            
            let responseData = responseObject as! Data
            
            if let JsonDict:[String:AnyObject] = try? JSONSerialization.jsonObject(with: responseData, options: .allowFragments) as! [String:AnyObject]{
                completion(JsonDict,true)
            }else {
                completion([:],false)
            }
            
        }, failure: { (operation : AFHTTPRequestOperation, error : Error) -> Void in
            
            print(error, terminator: "")
            
            completion([:],false)
            
        })
        
        manager.start()
    }
}
