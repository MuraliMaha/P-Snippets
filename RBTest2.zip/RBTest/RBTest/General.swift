//
//  General.swift
//  RBTest
//
//  Created by APPLE on 09/04/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit


struct ProductStruct {
    var Message : String!
    var DataArray = [ProductDataStruct]()
    var BrandsArray = [ProductBrandStruct]()
    var totalProducts : String!
    var Currency : String!
    
    
}
struct ProductDataStruct {
    var product_id : String!
    var product_title : String!
    var image_url : String!
    var category_id : String!
    var proRating : String!
    var totRating : String!
    var orgPrice : String!
    var sellPrice : String!
    var proPercentage : String!
    var productImgData : Data?
    
    
    var noOfItem : Int = 1
     var addToCartBtnViewFlag : Bool = false
}
struct ProductBrandStruct {
    var brand_id : String!
    var name : String!
}
func saveProductResponce(ProductResponce:[String:AnyObject]) {
    
    let Defaults = UserDefaults.standard
    
    let data = try? JSONSerialization.data(withJSONObject: ProductResponce, options: .prettyPrinted)
    Defaults.set(data, forKey: "ProductResponce")
    Defaults.synchronize()
}
func fetchProductResponce() -> ProductStruct? {
    
    if UserDefaults.standard.value(forKey: "ProductResponce") != nil
    {
        
        if let ResponceDict:[String:AnyObject] = try! JSONSerialization.jsonObject(with:UserDefaults.standard.value(forKey: "ProductResponce") as! Data, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:AnyObject]
        {
            
            var ResponceStruct = ProductStruct()
            
            ResponceStruct.Message = "\(ResponceDict["Message"]!)"
            ResponceStruct.totalProducts = "\(ResponceDict["totalProducts"]!)"
            ResponceStruct.Currency = "\(ResponceDict["Currency"]!)"
            
            var dataArr = [ProductDataStruct]()
            for aDict in ResponceDict["Data"] as! [[String:AnyObject]] {
                var structObj = ProductDataStruct()
                structObj.product_id = "\(aDict["product_id"]!)"
                structObj.product_title = "\(aDict["product_title"]!)"
                structObj.image_url = "\(aDict["image_url"]!)"
                structObj.category_id = "\(aDict["category_id"]!)"
                structObj.proRating = "\(aDict["proRating"]!)"
                structObj.totRating = "\(aDict["totRating"]!)"
                structObj.orgPrice = "\(aDict["orgPrice"]!)"
                structObj.sellPrice = "\(aDict["sellPrice"]!)"
                structObj.proPercentage = "\(aDict["proPercentage"]!)"
                dataArr.append(structObj)
            }
            ResponceStruct.DataArray = dataArr
            
            var brandArr = [ProductBrandStruct]()
            for aDict in ResponceDict["Brands"] as! [[String:AnyObject]]{
                var structObj = ProductBrandStruct()
                structObj.brand_id = "\(aDict["brand_id"]!)"
                structObj.name = "\(aDict["name"]!)"
                brandArr.append(structObj)
            }
            ResponceStruct.BrandsArray = brandArr

            return ResponceStruct
            
        }
        else
        {
            return nil
            
        }
        
    }
    else
    {
        return nil
    }
    
}




