//
//  SplashVC.swift
//  RBTest
//
//  Created by APPLE on 09/04/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class SplashVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.perform(#selector(self.Call), with: nil, afterDelay: 1)
    }
    
    @objc func Call(){
        if let productResponse = fetchProductResponce() {
            print("Data available...")
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerSBID") as! HomeViewController
            ctrl.hideCVContainer = false
            ctrl.theProductStruct = productResponse
            self.present(ctrl, animated: true, completion: nil)
            
        }else{
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewControllerSBID") as! HomeViewController
            ctrl.hideCVContainer = true
            self.present(ctrl, animated: true, completion: nil)
        }
    }
    
 
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
