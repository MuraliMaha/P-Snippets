//
//  ViewController.swift
//  TableViewTest1
//
//  Created by APPLE on 12/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myTV: UITableView!
    
    @IBOutlet weak var myHeaderView: UIView!
    @IBOutlet weak var myFooterView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.myTV.dataSource = self
        self.myTV.delegate = self
        
        self.myTV.reloadData()
    }


}
extension ViewController : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCellID", for: indexPath) as! MyCellClass
        cell.textLabel?.text = "Hai"
        return cell
    }
}
class MyCellClass : UITableViewCell {
    
}
