//
//  ViewController.swift
//  RufuTech
//
//  Created by APPLE on 09/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var lbl4: UILabel!
    
   
    
    let myStrArr = ["Apple","Ball","Cat","Dog","Egg","Fox","Goat","Hat","Ink","Jeep"]
    var mySet:Set<String> = Set()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let myLblArr = [lbl1,lbl2,lbl3,lbl4]
      
        for _ in 0..<myLblArr.count {
            var result = mySet.insert(myStrArr.randomElement()!)
            print("Inserted Result =",result)
            
            while !result.inserted{
                result = mySet.insert(myStrArr.randomElement()!)
                print("Inserted Result from while loop =",result)
            }
        }

        let resultArr = Array(mySet)
        for i in 0..<resultArr.count{
            myLblArr[i]?.text = resultArr[i]
        }
    }
    @IBAction func checkImgBtnTapped(_ sender: UIButton) {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "RandomImageVCSBID") as! RandomImageVC
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
}

