//
//  RandomImageVC.swift
//  RufuTechString
//
//  Created by APPLE on 10/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class RandomImageVC: UIViewController {

    @IBOutlet weak var imgView1: UIImageView!
    @IBOutlet weak var imgView2: UIImageView!
    @IBOutlet weak var imgView3: UIImageView!
    @IBOutlet weak var imgView4: UIImageView!
    
    let myImgArr = [UIImage.init(named: "Bear.jpeg"),
                    UIImage.init(named: "Cat.jpeg"),
                    UIImage.init(named: "Cock.jpeg"),
                    UIImage.init(named: "Dog.jpeg"),
                    UIImage.init(named: "Eagle.jpeg"),
                    UIImage.init(named: "Elephant.jpeg"),
                    UIImage.init(named: "Horse.jpeg"),
                    UIImage.init(named: "Lion.jpeg"),
                    UIImage.init(named: "Ostrich.jpeg"),
                    UIImage.init(named: "Owl.jpeg")]
    
//    let myImgNameArr = ["Bear.jpeg","Cat.jpeg","Cock.jpeg","Dog.jpeg","Eagle.jpeg","Elephant.jpeg","Horse.jpeg","Lion.jpeg","Ostrich.jpeg","Owl.jpeg"]
    
    var mySet:Set<Data> = Set()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let imgViewArr = [imgView1,imgView2,imgView3,imgView4]
        
//Method1:
        
    /*
        for _ in 0..<imgViewArr.count {
            let randomImg : UIImage! = myImgArr.randomElement()!
            var result = mySet.insert(randomImg.pngData()!)
            print("Inserted Result =",result)
            
            while !result.inserted{
                result = mySet.insert((myImgArr.randomElement()!?.pngData())!)
                print("Inserted Result from while loop =",result)
            }
        }
        
        let resultArr = Array(mySet)
        for i in 0..<resultArr.count{
            imgViewArr[i]?.image = UIImage(data: resultArr[i])
        } */
        
//Method2:
        let sequence = 0 ..< 10
        let shuffledSequence = sequence.shuffled()     // You put the sequence in random order
        let selection = shuffledSequence[0...3]        // You pick the first 4 items
        for i in 0..<imgViewArr.count {
            imgViewArr[i]!.image = myImgArr[selection[i]]
        }


        
        /*
        self.imgView1.image = self.myImgArr.randomElement() as? UIImage
        self.imgView2.image = self.myImgArr.randomElement() as? UIImage
        self.imgView3.image = self.myImgArr.randomElement() as? UIImage
        self.imgView4.image = self.myImgArr.randomElement() as? UIImage */
        
    
    }
    
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }


}
