//
//  HomePageVC.swift
//  RufuTech
//
//  Created by APPLE on 09/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class HomePageVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnTapped(_ sender: UIButton) {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerSBID") as! ViewController
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    /*
     @IBAction func BtnTapped(_ sender: UIButton) {
     }
    
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
