//
//  ViewController.swift
//  ViewHeightBasedOnitsContentTest1
//
//  Created by APPLE on 29/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        myLbl.text = "How to make a view height grow depending on its child views contents?.......You can accomplish this using AutoLayout.Make sure each of the child views has constraints defining its size and position. Then, set the parent views vertical content hugging and compression resistance priorities to required. This will define the parent's height based on the height and positioning of its child views.Note that depending on what the child views are, you may want to change their vertical content hugging and compression resistance priorities as well. For example, a UILabel with numberOfLines set to 0 can automatically grow based on its content, so you'd want it to hug its content vertically and resist vertical compression so that it resizes the parent view.This image shows the parent (white) view with its vertical hugging and compression resistance priorities set in the inspector panel. Notice that the parent view has constraints set for its width, x-position, and y-position, but not its height. It's able to infer its height based on the height and position of the child views......Ref:https://stackoverflow.com/questions/46835151/how-to-make-a-view-height-grow-depending-on-its-child-views-contents"
    }


    
}

