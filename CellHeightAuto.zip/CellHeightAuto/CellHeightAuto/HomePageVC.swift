//
//  HomePageVC.swift
//  CellHeightAuto
//
//  Created by APPLE on 06/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class HomePageVC: UIViewController {

    @IBAction func BtnTapped(_ sender: UIButton) {
        let DictInput = ["type":"oneway"]
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerSBID") as! ViewController
        ctrl.inputDict = DictInput
        self.present(ctrl, animated: true, completion: nil)
    }
    @IBAction func twowayBtnTapped(_ sender: UIButton) {
        let DictInput = ["type":"twoway"]
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerSBID") as! ViewController
        ctrl.inputDict = DictInput
        self.present(ctrl, animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
