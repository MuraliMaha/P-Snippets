//
//  ViewController.swift
//  CellHeightAuto
//
//  Created by APPLE on 06/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myTv: UITableView!
    var inputDict = [String:String]()
    var wayType : String!
    
    @IBAction func dismissBtnTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        myTv.dataSource = self
        myTv.delegate = self
        
        if inputDict["type"] == "oneway" {
            print("one way")
            self.wayType = "oneway"
        }else{
            print("two way")
            self.wayType = "twoway"
        }
    }


}
extension ViewController : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCellID", for: indexPath) as! MyCellClass
        
//        if self.wayType == "oneway" {
//            cell.orangeViewHeightCons.constant = 0
//        }else{
//            cell.orangeViewHeightCons.constant = 80
//        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableView.automaticDimension
        
                if self.wayType == "oneway" {
                    return 80
                }else{
                    return 160
                }
        
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}
class MyCellClass : UITableViewCell {
    @IBOutlet weak var blueView: UIView!
    @IBOutlet weak var orangeView: UIView!
    @IBOutlet weak var orangeViewHeightCons: NSLayoutConstraint!
}
