//
//  ViewController.swift
//  DoneBtnInNumericKeyboardTest1
//
//  Created by APPLE on 04/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITextFieldDelegate {

    @IBOutlet weak var myTxtField: UITextField!
    
    let button = UIButton(type: UIButton.ButtonType.custom)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.myTxtField.delegate = self
        
        button.setTitle("Done", for: UIControl.State())
        button.setTitleColor(UIColor.black, for: UIControl.State())
//        button.frame = CGRect(x: 0, y: 163, width: 106, height: 53)
//        button.adjustsImageWhenHighlighted = false
        button.addTarget(self, action: #selector(ViewController.Done(_:)), for: UIControl.Event.touchUpInside)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
    }

    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        UIView.setAnimationsEnabled(false)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
    }
    
    @objc func keyboardWillShow(_ note : Notification) -> Void{
        
        let height , width ,btnHeight,btnWidth : CGFloat
        width = CGFloat(UIScreen.main.bounds.width)
        let aStr = note.userInfo![UIKeyboardFrameEndUserInfoKey] as? NSValue
        height = (aStr?.cgRectValue.height)!
        
        btnHeight = height/4 // Four Rows
        btnWidth = (width/3) - 2 // Three Columns - 2px to account for lines
    
        DispatchQueue.main.async { () -> Void in
            self.button.isHidden = false
            let keyBoardWindow = UIApplication.shared.windows.last

            self.button.frame = CGRect(x: 0, y: ((keyBoardWindow?.frame.size.height)! - btnHeight)+1, width: btnWidth, height: btnHeight)
            keyBoardWindow?.addSubview(self.button)
            keyBoardWindow?.bringSubview(toFront: self.button)
            
        }
        
    }
    @objc func Done(_ sender : UIButton){
        
        DispatchQueue.main.async { () -> Void in
            UIView.setAnimationsEnabled(true)
            self.button.isHidden = true
            self.myTxtField.resignFirstResponder()
            
        }
    }

}

